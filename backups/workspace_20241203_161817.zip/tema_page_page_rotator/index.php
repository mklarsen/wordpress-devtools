<?php get_header(); ?>
<div id="main-content">
    <!-- Indholdet fra Page Rotator plugin -->
    <?php echo do_shortcode('[page_rotator]'); ?>
</div>
<?php get_footer(); ?>
